package FoodStorage;

public interface Identifiable {
    String getId();
}
