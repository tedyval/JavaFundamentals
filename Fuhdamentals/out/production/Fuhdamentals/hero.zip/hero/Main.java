package hero;

public class Main {
    public static void main(String[] args) {

        DarkWizard w = new DarkWizard("Zoro",3);
        System.out.println(w.toString());
    }
}
