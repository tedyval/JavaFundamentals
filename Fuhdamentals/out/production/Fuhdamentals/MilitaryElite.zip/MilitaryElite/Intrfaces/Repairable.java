package MilitaryElite.Intrfaces;

public interface Repairable {
    String getPartName();
    int getHoursWorked();
}
