package MilitaryElite.Intrfaces;

public interface Spy {
    int getCodeNumber();
}
