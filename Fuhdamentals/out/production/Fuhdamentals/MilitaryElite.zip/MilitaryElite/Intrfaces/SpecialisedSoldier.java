package MilitaryElite.Intrfaces;

import MilitaryElite.military.Corps;
import MilitaryElite.military.PrivateImpl;

public interface SpecialisedSoldier  {
    Corps getCorp();
}
