package MilitaryElite.Intrfaces;

public interface LieutenantGeneral {
    void addPrivate(Private priv);
}
