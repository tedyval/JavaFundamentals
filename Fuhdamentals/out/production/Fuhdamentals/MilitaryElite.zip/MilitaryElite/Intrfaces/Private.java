package MilitaryElite.Intrfaces;

public interface Private {
    double getSalary();
}
