package CarShopExtended;

public interface Sellable {
    Double getPrice();
}
