package CarShopExtended;

public interface Car {
    Integer TIRES = 4;

    String getModel();
    Integer getHorsePower();
    String getCountryProduced();
    String getColor();
}
