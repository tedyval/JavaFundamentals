package MultipleInheritance;

public class Main {
    public static void main(String[] args) {
        Puppy puppy = new Puppy();
        puppy.weep();
        puppy.bark();
        puppy.eat();



    }




}
